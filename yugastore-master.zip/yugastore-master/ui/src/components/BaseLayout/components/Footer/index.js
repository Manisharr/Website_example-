//Dependencies
import React from 'react';
//Internals
import './index.css';

const Footer = () => (
  <div className="footer">
    <p>Read more at YugaByte</p>
  </div>
)

export default Footer;
